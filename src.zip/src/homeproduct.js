const Homeproduct = 
[
    {
        id:1,
        Title:"Fresho Ginger - Organically Grown, 500 g",
        Cat: 'Ginger',
        Price: '83.22',
        Img: './img/tp1.jpg'
    },
    {
        id:2,
        Title:"Fresh Cucumber - English (Loose), 500 g",
        Cat: 'Cucumber',
        Price: '168',
        Img: './img/tp2.jpg'
    },
    {
        id:3,
        Title:"Fresh Pear - Green, Imported, 2x4 pcs Multipack",
        Cat: 'Pear',
        Price: '49',
        Img: './img/tp3.jpg'
    },
    {
        id:4,
        Title:"Fresh Amaranthus - Red Cleaned, without roots, 250 g",
        Cat: ' Amaranthus',
        Price: '22.5',
        Img: './img/tp4.jpg'
    },
    {
        id:5,
        Title:"Fresh Carrot - Orange (Loose), 250 g.",
        Cat: 'Carrot',
        Price: '12',
        Img: './img/tp5.jpg'
    },
    {
        id:6,
        Title:"Fresh Cauliflower, 1 pc (approx. 400 to 600 g)",
        Cat: 'Cauliflower',
        Price: '27.3',
        Img: './img/tp6.png'
    },
    {
        id:7,
        Title:"Fresh Onion - Organically Grown (Loose), 5 kg",
        Cat: 'Onion',
        Price: '196',
        Img: './img/tp7.png'
    },
    {
        id:8,
        Title:"Fresh Corriander - Organically Grown, 1 kg",
        Cat: 'Corriander',
        Price: '386',
        Img: './img/tp8.jpg'
    },
]
export default Homeproduct